//
//  FirstPageVC.swift
//  EmployeeManagement
//
//  Created by Jinyung Yoon on 08/09/2019.
//  Copyright © 2019 kings. All rights reserved.
//

import UIKit

class FirstPageVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
}
