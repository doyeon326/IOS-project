//
//  EmployeeManagement-Bridging-Header.h
//  EmployeeManagement
//
//  Created by kings on 18/09/2019.
//  Copyright © 2019 kings. All rights reserved.
//

#ifndef EmployeeManagement_Bridging_Header_h
#define EmployeeManagement_Bridging_Header_h

#import "SWRevealViewController.h"

#endif /* EmployeeManagement_Bridging_Header_h */
