//
//  PolicyPopUpViewController.swift
//  EmployeeManagement
//
//  Created by kings on 15/09/2019.
//  Copyright © 2019 kings. All rights reserved.
//

import UIKit

class PolicyPopUpViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    @IBAction func okButtonClick(_ sender: Any) {
        
        dismiss(animated: false, completion: nil)
    }
}
